Public release of the controlled two-host execution evidence.

This archive is derived from the frozen combined evidence archive identified in
PUBLIC_RELEASE.json. It retains reproducible source, canonical results, host
transcripts, and independent verification material. It excludes private host
metadata, IP/hostname snapshots, nonce logs, failed-run preservation, the nested
Host 2 provenance ZIP, Python caches, and patch backups.

No secret-share file, dealer/network seed, private key, credential, or access
token is included. The certificate is scoped to the declared finite service
language; it is not a deployment-wide or independent-operator claim.
