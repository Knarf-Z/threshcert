# Host 2 -- operator half of `paid_threshold_response_two_host_v3`

This machine runs four of the seven committee operators (2, 4, 6, 7). It holds
its own four secret shares and no others. It never holds the threshold key as a
whole, never aggregates, and never learns a plaintext. It answers `POST /respond`
with a partial decryption plus a Chaum-Pedersen proof, signed under its Schnorr
network key.

The proof nonce is derived inside the operator from its own share and the
ciphertext; the requester has no input to it. This is what stops host 1 from
extracting a share with two crafted queries.

Requires Python 3.10 or newer on PATH as `py -3`. No third-party packages.

## 1. Unpack and check

    Expand-Archive host2_bundle.zip -DestinationPath C:\ptr_host2
    cd C:\ptr_host2
    py -3 -c "import sys; print(sys.version)"

## 2. Open the firewall to host 1 only (run as Administrator)

Replace the address with host 1's LAN address.

    .\powershell\Open-Host2-Firewall.ps1 -Host1Address 192.168.31.8

## 3. Start the operators

    .\powershell\Start-Operators.ps1 -HostId host2

Expect `HOST2_OPERATORS_READY=4`. The operators load their secret shares from
`secrets\host2\` and the public keys from `config\committee.public.v3.json`.
The script refuses to start if this machine holds a secret file for an operator
it does not run.

## 4. Tell host 1 this machine's LAN address

    Get-NetIPAddress -AddressFamily IPv4 |
      Where-Object { $_.IPAddress -like "192.168.31.*" } |
      Select-Object -ExpandProperty IPAddress

Send that address to host 1. Host 1 writes it into `config/topology.v3.json` and
runs the experiment.

## During the experiment

Host 1 will ask you to do two things at specific points:

* **Outage test (groups C and D).** Run `.\powershell\Stop-Operators.ps1
  -HostId host2` and tell host 1. Host 1 then shows that a 4-of-7 threshold
  cannot be reached, that no partial plaintext is released, and that no local
  operator is silently substituted for a remote one.
* **Recovery test.** Run `.\powershell\Start-Operators.ps1 -HostId host2`
  again and tell host 1.

Replay protection persists to `results\host2\operator-*.nonces.log`, so a
restart does not forget answered orders. Host 1's runner salts each run with a
fresh id, so a legitimate re-run is never rejected as a replay.

## What is in this bundle

    src/ptr_v3/operator_server.py       the four-operator HTTP service
    src/ptr_v3/network_identity.py      Schnorr identity from a loaded secret key
    src/ptr_v3/crypto.py                threshold ElGamal, Chaum-Pedersen proofs
    src/ptr_v3/utils.py                 canonical JSON and hashing
    config/committee.public.v3.json     public keys and shares -- NO seed, NO secret
    config/host2.v3.json                this host's operators and ports
    secrets/host2/operator-2,4,6,7.secret.json   this host's four shares
    powershell/                         start, stop, firewall

There is no `seed`, no `network_seed`, and no other host's secret anywhere in
this bundle. Host 1's shares are not derivable from anything here.
