Host 2 evidence export for paid_threshold_response_two_host_v3

Contains:
- Operator 2/4/6/7 append-only transcripts
- Public committee bundle
- Host 2 source and PowerShell launch scripts
- Private runtime metadata in a separate subtree

Explicitly excluded:
- operator-*.secret.json
- dealer/network seeds
- all secret-key directories

This archive alone is not the combined two-host artifact.
