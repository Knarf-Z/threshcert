# `paid_threshold_response_two_host_v3`

A controlled 4-of-7 threshold-decryption experiment run across two machines. It
produces a *positive* evidence certificate — a ledger-derived lower bound on the
named buyer's net outflow for one execution — together with the proof objects
the five bridge gates read, and a witness deciding whether the two hosts were
really two machines.

This is a controlled experiment, not a deployment measurement. Every scope
boundary below is also recorded inside `canonical_result.v3.json`, so a reader
checking the JSON never has to take the prose on trust.

## What it establishes

* One 4-of-7 threshold decryption cannot complete from either host alone. With
  host 2 stopped, host 1 holds three shares, reaches no threshold, releases no
  usable plaintext, and does not silently substitute a local operator for an
  unreachable remote one.
* The execution floor is derived from the order ledger via an allocation
  witness, never from the closed form. If the allocation witness fails any of
  its clauses the report says `UNKNOWN` and carries no floor at all.
* Over all 840 ordered 4-subsets of the committee, the minimum ledger-derived
  floor equals the closed-form cover (10), attained by exactly 24 routes.
* Seven distinct fault injections — tampered partial, tampered proof, relabelled
  buyer, relabelled order, bumped epoch, impersonated operator, replayed
  response — are each rejected for their own reason, and none certifies.

## What it does not establish

| Not claimed | Why |
| --- | --- |
| Deployment-wide non-exportability | (C1) is proved over a declared finite service language: two HTTP routes and the module set hashed in the witness. No attestation, no HSM, no TEE. |
| Independent economic operators | Both machines are under one person's control. The committee is split across failure domains, not across interests. |
| Distributed key generation | A trusted dealer runs a one-time ceremony and splits the material; both hosts then run from their own secret files, not from a shared seed. A deployment would replace the ceremony with a DKG. |
| Cryptographic randomness | `random.Random` seeds the *dealer* only. Operator proof nonces and Schnorr nonces are deterministic (RFC 6979 style) and derived inside the operator, so results replay. |

## Key isolation

The outage claim is only meaningful if host 1 cannot simply regenerate the remote
shares. Earlier iterations shipped a single `committee.json` carrying the seed, so
either host could recompute all seven shares and forge any operator's network
key. That is fixed:

* A one-time dealer ceremony (`scripts/deal_keys.py`) runs on host 1 and splits
  the material into a *public* committee bundle — public keys only, no seed, no
  secret — plus one secret file per operator.
* Host 1 keeps only operators 1, 3, 5's secret files; host 2's four secret files
  go into the bundle and nowhere else. The dealer seed never leaves host 1 and
  never enters any shipped artifact or the canonical result.
* `readiness.key_isolation_witness` checks at run time that host 1's secret
  directory holds only its own operators and that the public bundle carries no
  secret. `scope.cross_host_dependency_established` is the conjunction of this
  and the separation witness; only when both pass may the run be quoted as a
  two-host result. The run prints `RUN_CLASS=CERTIFIED_TWO_HOST` or
  `NETWORK_SMOKE_TEST_ONLY` accordingly.

The Chaum–Pedersen proof nonce is derived inside the operator from its own share
and the ciphertext. The requester supplies no proof randomness, so host 1 cannot
steer an operator into reusing a witness across two ciphertexts — the two-query
share-extraction attack that a requester-chosen nonce would enable.

## The separation witness

Nothing else in the artifact establishes that the two hosts are two machines.
`operator_hosts` in the committee file is a label host 1 chose; an operator's
`host_id` is a string it reports about itself. A single machine can serve both
labels on two ports and every signature, proof and gate still passes.

`readiness.separation_witness` is the only place the claim is decided, and it is
decided from what host 1 observed:

* the TCP peer address of a live connection to each operator, as the kernel
  resolved it — loopback, or equal to host 1's own address on that connection,
  is a counterexample;
* a self-reported machine fingerprint from `GET /health` — equal to host 1's own
  fingerprint is a counterexample, and a missing one fails closed.

`PASS` needs both. A difference in fingerprints does not *prove* separation —
the value is unattested, like every other host claim here — but a match refutes
it, and the address check is what host 1 saw rather than what it was told.

`scope.independent_failure_domains` is derived from this witness. A loopback
rehearsal is a legitimate run and completes normally; it reports
`independent_failure_domains: 1`, `two_physical_hosts_established: false`, and
`host_separation_status: FAIL_COUNTEREXAMPLE`. Only a run whose witness passes
may be described as two-host.

Addresses and fingerprints identify a particular pair of machines, so they are
recorded in `run_metadata.v3.json`; the canonical result carries only the
verdicts, which are identical on any correctly separated pair.

## Running it

Host 1 is the coordinator and runs operators 1, 3, 5. Host 2 runs operators
2, 4, 6, 7 and nothing else. Python 3.10+ on both, no third-party packages.

On host 1, run the key ceremony once, then build and hand over the host-2 half:

```bash
powershell -File powershell/Setup-Host1.ps1
```

```bash
py -3 scripts/package_host2.py
```

`Setup-Host1.ps1` mints `config/committee.public.v3.json` and host 1's three
secret files; `package_host2.py` re-derives the same public bundle, stages host
2's four secret files, and refuses to build if the bundle would carry a seed or a
foreign secret.

On host 2, unpack `dist/host2_bundle.zip` and follow its README: open the
firewall to host 1's address only, then `Start-Operators.ps1 -HostId host2`.

Back on host 1, put host 2's LAN address into `config/topology.v3.json`, then:

```bash
py -3 -m unittest discover -s tests
```

```bash
powershell -File powershell/Run-TwoHost-Experiment.ps1
```

That script starts host 1's operators, checks host 2 is reachable and reports a
different machine, runs groups A/B/E/X and the fault matrix, then drives the
outage and recovery phases automatically. It does not block on a keypress: it
prints `WAITING_FOR_HOST2_OUTAGE` and polls until host 2's operators are down
before the outage tests, then prints `WAITING_FOR_HOST2_RECOVERY` and polls until
`REMOTE_RECOVERY_READY=4/4` before the recovery test. The only manual actions are
physically stopping and restarting host 2's operators when prompted.
`Start-Operators.ps1` is idempotent — it reuses a port already serving the correct
operator and only clears a wrong or dead one — so re-invoking it never disturbs a
healthy committee or leaves a stale process to skew the outage test.

Finally, re-derive every acceptance condition from the emitted JSON alone:

```bash
py -3 scripts/verify_two_host.py
```

`verify_two_host.py` never imports the experiment. It recomputes the cover from
the floors, re-enumerates the 840 routes, re-checks the allocation clauses, and
asserts the scope block claims no more separation than the witness established.

## Operational notes

* **Replay protection is per operator process.** Nonces are deterministic in the
  order id, so re-running an identical order against still-live operators is
  correctly rejected. If host 1 reports zero accepted responses, restart both
  hosts' operators — `Start-Operators.ps1` stops any listener on the configured
  ports first, so it is safe to re-run.
* **The 840-route enumeration is 3,360 real HTTP round trips** and takes roughly
  16 minutes. `--skip-routes` runs everything else in about a minute.
* **A VPN adapter can change what `getpeername` reports.** If host 1 has a
  tunnel up, confirm the LAN address in `topology.v3.json` is the one the
  separation witness observes.

## Layout

    src/ptr_v3/operator_server.py   two HTTP routes; the only thing host 2 runs
    src/ptr_v3/coordinator.py       seven checks on every response, plus endpoint probing
    src/ptr_v3/crypto.py            threshold ElGamal, Chaum-Pedersen partial proofs
    src/ptr_v3/network_identity.py  Schnorr identity from a loaded secret key, registry
    src/ptr_v3/dealer.py            the one-time key ceremony and the public/secret split
    src/ptr_v3/ledger.py            the order ledger the floor is derived from
    src/ptr_v3/witness.py           aggregation, allocation, coverage, separation, key isolation
    src/ptr_v3/evidence.py          four-valued gates, three-valued report
    src/ptr_v3/certificate.py       theory cover, catalog certificate, weighted DP
    scripts/deal_keys.py            runs the ceremony, writes one host's material
    scripts/run_two_host.py         groups A/B/E/X and the fault matrix
    scripts/run_outage_test.py      groups C and D, and `--recovery`
    scripts/verify_two_host.py      independent acceptance check over the JSON
    scripts/package_host2.py        builds dist/host2_bundle.zip
