# Two-host v4: code-to-manifest fidelity upgrade

This is an **overlay** for `paid_threshold_response_two_host_v3`; it does not replace the existing experiment.
Extract the ZIP into the project root so the new `scripts/` and `powershell/` files sit beside the existing ones.

## Why this upgrade exists

The v3 experiment already checks real threshold ElGamal, 840 ordered four-responder routes, allocation disjointness,
a free-bypass refutation, a shared-debit refusal, host separation, key isolation, and outage/recovery. Its largest explicit
residual is the fidelity of the declared component manifest to the real controlled implementation.

This module narrows that residual for the controlled Python/PowerShell tree by freezing and independently re-deriving:

- the exact set and SHA-256 of runtime `.py` and `.ps1` files under `src/ptr_v3`, `scripts`, and `powershell`;
- server-side HTTP handler methods and route literals (expected exactly `/health` and `/respond`);
- response-emission sites in HTTP handlers;
- HTTP/TCP server-constructor sites;
- dynamic-code execution sites (`eval`, `exec`, `importlib.import_module`, etc.);
- subprocess/process-spawn sites;
- sensitive PowerShell constructs such as `Invoke-Expression`, `Start-Process`, listeners, and `Add-Type`.

It is deliberately fail-closed: any new runtime file, byte drift, producer route, listener, or dynamic execution surface
invalidates the frozen baseline. It does **not** claim arbitrary-program semantic equivalence, OS/firmware/hardware closure,
or discovery of off-tree/off-language routes.

## Run on Host 1

From the project root:

```powershell
Set-Location "D:\paper_project\paid_threshold_response_two_host_v3"
```

### 1. Install this overlay

Extract this ZIP into the project root. Do not overwrite the existing v3 files; all filenames in this overlay are new.

### 2. Freeze once, after reviewing the intended baseline

```powershell
Set-ExecutionPolicy -Scope Process Bypass -Force
.\powershell\Initialize-Code-Fidelity.ps1
```

Expected tail:

```text
PUBLIC_HTTP_ROUTES=/health,/respond
CODE_MANIFEST_FREEZE=PASS
CODE_TO_MANIFEST_FIDELITY=PASS
CODE_FIDELITY_INITIALIZATION=PASS
```

This creates:

- `config/code_manifest.v1.json`
- `config/code_manifest.v1.sha256`
- `results/code_manifest_binding.v1.json`

**Do not rebuild the manifest during ordinary verification.** A rebuild is an intentional new experiment version.

### 3. Run the adversarial mutation matrix

```powershell
.\powershell\Run-Code-Fidelity-Mutations.ps1
```

It mutates temporary copies only; the real project tree is untouched. Expected tail:

```text
MUTATION_BYTE_HASH_DRIFT=CAUGHT
MUTATION_UNDECLARED_RUNTIME_FILE=CAUGHT
MUTATION_UNDECLARED_HTTP_ROUTE=CAUGHT
MUTATION_DYNAMIC_EXEC=CAUGHT
MUTATION_SECONDARY_LISTENER=CAUGHT
MUTATION_POWERSHELL_DYNAMIC_EXECUTION=CAUGHT
MUTATIONS_CAUGHT=6/6
CODE_MANIFEST_MUTATION_MATRIX=PASS
```

It writes `results/code_manifest_mutation_matrix.v1.json`.

### 4. Normal re-verification

```powershell
.\powershell\Verify-Code-Fidelity.ps1
```

### 5. Full v4 evidence run

Keep Host 2 operators running exactly as in v3, then run:

```powershell
.\powershell\Run-TwoHost-V4-Evidence.ps1
```

This preserves the existing v3 canonical run and outage/recovery workflow, then requires both the existing independent
verifier and the new code-fidelity verifier/mutation matrix to pass.

## Paper-safe claim

A safe claim is:

> For the controlled Python/PowerShell implementation, a frozen code manifest is byte-bound to the runtime tree and its
> HTTP producer, server-constructor, dynamic-code, process-spawn, and PowerShell-sensitive surfaces are independently
> re-derived. Six temporary mutations—byte drift, an undeclared runtime file, an undeclared HTTP route, dynamic execution,
> a secondary listener, and PowerShell dynamic execution—are all rejected. This narrows the manifest-to-code fidelity
> residual for the controlled service; it does not establish deployment-wide closure outside the pinned code tree.

Do not claim that this proves arbitrary binary equivalence, hardware non-exportability, seven independent operators, or
production deployment-wide B5 closure.

## Export the new evidence only

After verification and the mutation matrix pass:

```powershell
.\powershell\Export-Code-Fidelity-Evidence.ps1
```

This exports a public ZIP containing the frozen manifest/digest, verifier sources, and the two canonical fidelity results.
It deliberately excludes `secrets/`, host addresses, nonce logs, and private run metadata.
