param(
    [string]$Destination = "$env:USERPROFILE\Desktop"
)

$ErrorActionPreference = "Stop"
$Root = Split-Path -Parent $PSScriptRoot
Set-Location $Root

$Required = @(
    ".\config\code_manifest.v1.json",
    ".\config\code_manifest.v1.sha256",
    ".\results\code_manifest_binding.v1.json",
    ".\results\code_manifest_mutation_matrix.v1.json",
    ".\scripts\fidelity_core.py",
    ".\scripts\build_code_manifest.py",
    ".\scripts\verify_code_manifest.py",
    ".\scripts\run_code_manifest_mutations.py"
)
foreach ($Path in $Required) {
    if (-not (Test-Path $Path)) { throw "missing fidelity evidence file: $Path" }
}

$Stamp = Get-Date -Format "yyyyMMdd_HHmmss"
$Stage = Join-Path $env:TEMP "ptr_code_fidelity_$Stamp"
$Zip = Join-Path $Destination "ptr_code_fidelity_evidence_$Stamp.zip"
New-Item -ItemType Directory -Force -Path $Stage | Out-Null
New-Item -ItemType Directory -Force -Path (Join-Path $Stage "config") | Out-Null
New-Item -ItemType Directory -Force -Path (Join-Path $Stage "results") | Out-Null
New-Item -ItemType Directory -Force -Path (Join-Path $Stage "scripts") | Out-Null

Copy-Item .\config\code_manifest.v1.json (Join-Path $Stage "config")
Copy-Item .\config\code_manifest.v1.sha256 (Join-Path $Stage "config")
Copy-Item .\results\code_manifest_binding.v1.json (Join-Path $Stage "results")
Copy-Item .\results\code_manifest_mutation_matrix.v1.json (Join-Path $Stage "results")
Copy-Item .\scripts\fidelity_core.py (Join-Path $Stage "scripts")
Copy-Item .\scripts\build_code_manifest.py (Join-Path $Stage "scripts")
Copy-Item .\scripts\verify_code_manifest.py (Join-Path $Stage "scripts")
Copy-Item .\scripts\run_code_manifest_mutations.py (Join-Path $Stage "scripts")

Compress-Archive -Path (Join-Path $Stage "*") -DestinationPath $Zip -Force
$Hash = (Get-FileHash -Algorithm SHA256 $Zip).Hash
Write-Host "CODE_FIDELITY_EVIDENCE=$Zip"
Write-Host "CODE_FIDELITY_EVIDENCE_SHA256=$Hash"
Remove-Item -Recurse -Force $Stage
