$ErrorActionPreference = "Stop"
$Root = Split-Path -Parent $PSScriptRoot
Set-Location $Root

if (-not (Test-Path .\config\code_manifest.v1.json)) {
    throw "Frozen code manifest missing. Run .\powershell\Initialize-Code-Fidelity.ps1 once after reviewing the code baseline."
}

# Preserve the existing canonical two-host experiment and its outage/recovery workflow.
& .\powershell\Run-TwoHost-Experiment.ps1
if ($LASTEXITCODE -ne 0) { throw "existing two-host experiment failed" }

& py -3.11 .\scripts\verify_two_host.py
if ($LASTEXITCODE -ne 0) { throw "existing independent two-host verification failed" }

& py -3.11 .\scripts\verify_code_manifest.py
if ($LASTEXITCODE -ne 0) { throw "code-to-manifest fidelity failed" }

& py -3.11 .\scripts\run_code_manifest_mutations.py
if ($LASTEXITCODE -ne 0) { throw "code-manifest mutation matrix failed" }

Write-Host "TWO_HOST_V4_EVIDENCE=PASS"
