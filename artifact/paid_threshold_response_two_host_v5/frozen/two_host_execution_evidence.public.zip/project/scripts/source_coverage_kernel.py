from __future__ import annotations

import argparse
import ast
import hashlib
import json
from pathlib import Path
from typing import Any, Iterable

ROOT = Path(__file__).resolve().parents[1]
SOURCE_ROOT = Path("src/ptr_v3")
SCHEMA = "ptr-source-coverage-kernel/v1"

EXPECTED_SOURCE_FILES = (
    "__init__.py",
    "capability.py",
    "certificate.py",
    "checker.py",
    "contracts.py",
    "coordinator.py",
    "crypto.py",
    "dealer.py",
    "evidence.py",
    "experiment.py",
    "ledger.py",
    "network_identity.py",
    "operator_server.py",
    "service_model.py",
    "utils.py",
    "witness.py",
)
EXPECTED_OPERATOR_IMPORT_CLOSURE = (
    "ptr_v3.__init__",
    "ptr_v3.crypto",
    "ptr_v3.network_identity",
    "ptr_v3.operator_server",
    "ptr_v3.utils",
)
EXPECTED_HANDLER_METHODS = ("_send", "do_GET", "do_POST", "log_message")
EXPECTED_ENTRY_ROUTES = {"do_GET": "/health", "do_POST": "/respond"}
EXPECTED_CIPHERTEXT_FIELDS = (
    "c1",
    "c2",
    "buyer",
    "resource",
    "order_id",
    "plaintext_commitment",
)

DYNAMIC_CALLS = {
    "eval",
    "exec",
    "compile",
    "__import__",
    "importlib.import_module",
    "importlib.reload",
    "runpy.run_module",
    "runpy.run_path",
    "ctypes.CDLL",
    "ctypes.PyDLL",
}
PROCESS_CALL_PREFIXES = (
    "subprocess.",
    "os.system",
    "os.popen",
    "asyncio.create_subprocess",
    "multiprocessing.Process",
)
LISTENER_TAILS = {
    "HTTPServer",
    "ThreadingHTTPServer",
    "TCPServer",
    "ThreadingTCPServer",
    "UnixStreamServer",
    "ThreadingUnixStreamServer",
    "create_server",
    "start_server",
}
FORBIDDEN_IMPORT_ROOTS = {"importlib", "runpy", "subprocess", "ctypes", "multiprocessing"}
SENSITIVE_STATE_ATTRIBUTES = {"share", "public_share", "identity"}


def sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest().upper()


def call_name(node: ast.AST) -> str:
    if isinstance(node, ast.Name):
        return node.id
    if isinstance(node, ast.Attribute):
        prefix = call_name(node.value)
        return f"{prefix}.{node.attr}" if prefix else node.attr
    return ""


def attribute_name(node: ast.AST) -> str:
    return call_name(node)


def parent_map(tree: ast.AST) -> dict[ast.AST, ast.AST]:
    return {child: parent for parent in ast.walk(tree) for child in ast.iter_child_nodes(parent)}


def context_of(node: ast.AST, parents: dict[ast.AST, ast.AST]) -> str:
    names: list[str] = []
    current: ast.AST | None = node
    while current is not None:
        if isinstance(current, (ast.FunctionDef, ast.AsyncFunctionDef, ast.ClassDef)):
            names.append(current.name)
        current = parents.get(current)
    return ".".join(reversed(names))


def nearest(node: ast.AST, parents: dict[ast.AST, ast.AST], kinds: tuple[type[ast.AST], ...]) -> ast.AST | None:
    current = parents.get(node)
    while current is not None:
        if isinstance(current, kinds):
            return current
        current = parents.get(current)
    return None


def parse_sources(root: Path) -> tuple[dict[str, ast.Module], dict[str, str]]:
    base = root / SOURCE_ROOT
    trees: dict[str, ast.Module] = {}
    errors: dict[str, str] = {}
    for path in sorted(base.glob("*.py")):
        try:
            trees[path.name] = ast.parse(path.read_text(encoding="utf-8"), filename=path.as_posix())
        except (UnicodeDecodeError, SyntaxError) as error:
            errors[path.name] = str(error)
    return trees, errors


def module_to_file(module: str) -> str | None:
    if module == "ptr_v3":
        return "__init__.py"
    if module.startswith("ptr_v3."):
        return module.split(".", 1)[1] + ".py"
    return None


def local_imports(module: str, tree: ast.Module) -> set[str]:
    found: set[str] = set()
    package = module.rsplit(".", 1)[0]
    for node in ast.walk(tree):
        if isinstance(node, ast.Import):
            for alias in node.names:
                if alias.name == "ptr_v3" or alias.name.startswith("ptr_v3."):
                    found.add(alias.name)
        elif isinstance(node, ast.ImportFrom):
            if node.level:
                base = package
                if node.module:
                    target = f"{base}.{node.module}"
                    found.add(target)
                else:
                    for alias in node.names:
                        found.add(f"{base}.{alias.name}")
            elif node.module and (node.module == "ptr_v3" or node.module.startswith("ptr_v3.")):
                found.add(node.module)
    return found


def operator_import_closure(trees: dict[str, ast.Module]) -> tuple[set[str], list[str]]:
    pending = ["ptr_v3.operator_server"]
    closure = {"ptr_v3.__init__"}
    missing: list[str] = []
    while pending:
        module = pending.pop()
        if module in closure:
            continue
        closure.add(module)
        filename = module_to_file(module)
        if filename is None or filename not in trees:
            missing.append(module)
            continue
        for imported in local_imports(module, trees[filename]):
            if imported not in closure:
                pending.append(imported)
    return closure, sorted(missing)


def find_classes(trees: dict[str, ast.Module], base_tail: str) -> list[tuple[str, ast.ClassDef, dict[ast.AST, ast.AST]]]:
    found: list[tuple[str, ast.ClassDef, dict[ast.AST, ast.AST]]] = []
    for filename, tree in trees.items():
        parents = parent_map(tree)
        for node in ast.walk(tree):
            if isinstance(node, ast.ClassDef) and any(call_name(base).rsplit(".", 1)[-1] == base_tail for base in node.bases):
                found.append((filename, node, parents))
    return found


def class_methods(cls: ast.ClassDef) -> dict[str, ast.FunctionDef | ast.AsyncFunctionDef]:
    return {
        node.name: node
        for node in cls.body
        if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef))
    }


def is_route_guard(function: ast.FunctionDef | ast.AsyncFunctionDef, route: str) -> bool:
    body = list(function.body)
    if body and isinstance(body[0], ast.Expr) and isinstance(body[0].value, ast.Constant) and isinstance(body[0].value.value, str):
        body = body[1:]
    if not body or not isinstance(body[0], ast.If):
        return False
    guard = body[0]
    test = guard.test
    if not (
        isinstance(test, ast.Compare)
        and isinstance(test.left, ast.Attribute)
        and attribute_name(test.left) == "self.path"
        and len(test.ops) == 1
        and isinstance(test.ops[0], ast.NotEq)
        and len(test.comparators) == 1
        and isinstance(test.comparators[0], ast.Constant)
        and test.comparators[0].value == route
    ):
        return False
    has_404 = False
    has_return = False
    for node in ast.walk(guard):
        if isinstance(node, ast.Call) and call_name(node.func).endswith("._send"):
            if node.args and isinstance(node.args[0], ast.Constant) and node.args[0].value == 404:
                has_404 = True
        if isinstance(node, ast.Return):
            has_return = True
    routes = {
        node.value
        for node in ast.walk(function)
        if isinstance(node, ast.Constant) and isinstance(node.value, str) and node.value.startswith("/")
    }
    return has_404 and has_return and routes == {route}


def dict_keys(node: ast.Dict) -> list[str]:
    keys: list[str] = []
    for key in node.keys:
        if isinstance(key, ast.Constant) and isinstance(key.value, str):
            keys.append(key.value)
    return keys


def assigned_attribute_targets(node: ast.AST) -> Iterable[ast.Attribute]:
    targets: list[ast.AST] = []
    if isinstance(node, ast.Assign):
        targets.extend(node.targets)
    elif isinstance(node, ast.AnnAssign):
        targets.append(node.target)
    elif isinstance(node, ast.AugAssign):
        targets.append(node.target)
    for target in targets:
        for child in ast.walk(target):
            if isinstance(child, ast.Attribute):
                yield child


def assigned_name(node: ast.AST, name: str) -> bool:
    if isinstance(node, ast.Assign):
        return any(isinstance(target, ast.Name) and target.id == name for target in node.targets)
    if isinstance(node, ast.AnnAssign):
        return isinstance(node.target, ast.Name) and node.target.id == name
    return False


def assignment_value(node: ast.AST) -> ast.AST | None:
    if isinstance(node, (ast.Assign, ast.AnnAssign)):
        return node.value
    return None


def compare_actual_consumer(value: ast.AST) -> bool:
    if not isinstance(value, ast.BoolOp) or not isinstance(value.op, ast.And) or len(value.values) != 2:
        return False
    names = {call_name(value.values[0]), call_name(value.values[1])}
    if "aggregate_valid" not in names:
        return False
    comparison = value.values[0] if isinstance(value.values[0], ast.Compare) else value.values[1]
    return (
        isinstance(comparison, ast.Compare)
        and call_name(comparison.left) == "actual_consumer"
        and len(comparison.ops) == 1
        and isinstance(comparison.ops[0], ast.Eq)
        and len(comparison.comparators) == 1
        and call_name(comparison.comparators[0]) == "ciphertext.buyer"
    )


def analyze(root: Path) -> dict[str, Any]:
    root = root.resolve()
    trees, parse_errors = parse_sources(root)
    actual_files = tuple(sorted(trees))
    checks: dict[str, bool] = {}
    diagnostics: dict[str, Any] = {"parse_errors": parse_errors}

    checks["PYTHON_SYNTAX"] = not parse_errors
    checks["SOURCE_MODULE_SET_EXACT"] = actual_files == tuple(sorted(EXPECTED_SOURCE_FILES))

    closure, missing_imports = operator_import_closure(trees)
    checks["OPERATOR_IMPORT_CLOSURE_EXACT"] = (
        tuple(sorted(closure)) == tuple(sorted(EXPECTED_OPERATOR_IMPORT_CLOSURE))
        and not missing_imports
    )
    diagnostics["operator_import_closure"] = sorted(closure)
    diagnostics["missing_local_imports"] = missing_imports

    handler_classes = find_classes(trees, "BaseHTTPRequestHandler")
    checks["HANDLER_CLASS_EXACT"] = (
        len(handler_classes) == 1
        and handler_classes[0][0] == "operator_server.py"
        and handler_classes[0][1].name == "Handler"
    )

    handler_methods: dict[str, ast.FunctionDef | ast.AsyncFunctionDef] = {}
    handler_parents: dict[ast.AST, ast.AST] = {}
    if len(handler_classes) == 1:
        _, handler, handler_parents = handler_classes[0]
        handler_methods = class_methods(handler)
    checks["REQUEST_ENTRY_METHODS_EXACT"] = (
        tuple(sorted(handler_methods)) == tuple(sorted(EXPECTED_HANDLER_METHODS))
        and tuple(sorted(name for name in handler_methods if name.startswith("do_"))) == tuple(sorted(EXPECTED_ENTRY_ROUTES))
    )
    checks["ROUTE_GUARDS_EXACT"] = all(
        name in handler_methods and is_route_guard(handler_methods[name], route)
        for name, route in EXPECTED_ENTRY_ROUTES.items()
    )

    raw_sinks: list[dict[str, Any]] = []
    send_calls: list[dict[str, Any]] = []
    if len(handler_classes) == 1:
        filename, handler, parents = handler_classes[0]
        for node in ast.walk(handler):
            if not isinstance(node, ast.Call):
                continue
            name = call_name(node.func)
            context = context_of(node, parents)
            if name in {"self.send_response", "self.send_header", "self.end_headers", "self.wfile.write"}:
                raw_sinks.append({"file": filename, "line": node.lineno, "call": name, "context": context})
            if name == "self._send":
                send_calls.append({"file": filename, "line": node.lineno, "context": context})
        forbidden_handler_attrs = [
            {"line": node.lineno, "attr": attribute_name(node)}
            for node in ast.walk(handler)
            if isinstance(node, ast.Attribute) and attribute_name(node) in {"self.connection", "self.request"}
        ]
    else:
        forbidden_handler_attrs = []
    sink_contexts = {item["context"] for item in raw_sinks}
    sink_names = {item["call"] for item in raw_sinks}
    send_contexts = {item["context"].rsplit(".", 1)[-1] for item in send_calls}
    checks["RESPONSE_PRIMITIVE_UNIQUE"] = (
        sink_contexts == {"build_handler.Handler._send"}
        and {"self.send_response", "self.send_header", "self.end_headers", "self.wfile.write"} <= sink_names
        and send_contexts <= {"do_GET", "do_POST"}
        and not forbidden_handler_attrs
    )
    diagnostics["raw_response_sinks"] = raw_sinks
    diagnostics["send_primitive_calls"] = send_calls
    diagnostics["forbidden_handler_attributes"] = forbidden_handler_attrs

    all_calls: list[dict[str, Any]] = []
    all_import_roots: list[dict[str, Any]] = []
    listener_sites: list[dict[str, Any]] = []
    dynamic_sites: list[dict[str, Any]] = []
    process_sites: list[dict[str, Any]] = []
    for filename, tree in trees.items():
        parents = parent_map(tree)
        for node in ast.walk(tree):
            if isinstance(node, (ast.Import, ast.ImportFrom)):
                modules: list[str] = []
                if isinstance(node, ast.Import):
                    modules = [alias.name for alias in node.names]
                elif node.module:
                    modules = [node.module]
                for module in modules:
                    root_name = module.split(".", 1)[0]
                    if root_name in FORBIDDEN_IMPORT_ROOTS:
                        all_import_roots.append({"file": filename, "line": node.lineno, "module": module})
            if not isinstance(node, ast.Call):
                continue
            name = call_name(node.func)
            record = {"file": filename, "line": node.lineno, "call": name, "context": context_of(node, parents)}
            all_calls.append(record)
            tail = name.rsplit(".", 1)[-1]
            if name in DYNAMIC_CALLS or name in {"setattr", "delattr"}:
                dynamic_sites.append(record)
            if any(name == prefix or name.startswith(prefix) for prefix in PROCESS_CALL_PREFIXES):
                process_sites.append(record)
            if tail in LISTENER_TAILS:
                listener_sites.append(record)

    checks["NO_DYNAMIC_LOADING"] = not dynamic_sites and not all_import_roots
    checks["NO_PROCESS_SPAWN"] = not process_sites
    checks["SINGLE_LISTENER"] = (
        len(listener_sites) == 1
        and listener_sites[0]["file"] == "operator_server.py"
        and listener_sites[0]["context"] == "serve"
        and sum(1 for item in all_calls if item["file"] == "operator_server.py" and item["call"] == "serve") == 1
    )
    diagnostics["dynamic_sites"] = dynamic_sites
    diagnostics["forbidden_imports"] = all_import_roots
    diagnostics["process_sites"] = process_sites
    diagnostics["listener_sites"] = listener_sites

    operator_tree = trees.get("operator_server.py")
    producer_sites: list[dict[str, Any]] = []
    state_share_loads: list[dict[str, Any]] = []
    sensitive_writes: list[dict[str, Any]] = []
    response_flow_ok = False
    no_secret_response = False
    if operator_tree is not None:
        parents = parent_map(operator_tree)
        for node in ast.walk(operator_tree):
            if isinstance(node, ast.Call) and call_name(node.func).rsplit(".", 1)[-1] == "create_partial":
                producer_sites.append(
                    {"line": node.lineno, "context": context_of(node, parents), "args": [ast.unparse(arg) for arg in node.args]}
                )
            if isinstance(node, ast.Attribute) and attribute_name(node) == "state.share" and isinstance(node.ctx, ast.Load):
                parent = parents.get(node)
                state_share_loads.append(
                    {
                        "line": node.lineno,
                        "context": context_of(node, parents),
                        "inside_create_partial": isinstance(parent, ast.Call)
                        and call_name(parent.func).rsplit(".", 1)[-1] == "create_partial",
                    }
                )
            for target in assigned_attribute_targets(node):
                name = attribute_name(target)
                if name in {f"self.{attr}" for attr in SENSITIVE_STATE_ATTRIBUTES} or name in {
                    f"state.{attr}" for attr in SENSITIVE_STATE_ATTRIBUTES
                }:
                    sensitive_writes.append(
                        {"line": node.lineno, "target": name, "context": context_of(node, parents)}
                    )

        post_functions = [
            node for node in ast.walk(operator_tree)
            if isinstance(node, ast.FunctionDef) and node.name == "do_POST"
        ]
        if len(post_functions) == 1:
            post = post_functions[0]
            tuple_assignment = any(
                isinstance(node, ast.Assign)
                and any(
                    isinstance(target, ast.Tuple)
                    and [elt.id for elt in target.elts if isinstance(elt, ast.Name)]
                    == ["response", "partial_hash", "proof_hash"]
                    for target in node.targets
                )
                and isinstance(node.value, ast.Call)
                and call_name(node.value.func).rsplit(".", 1)[-1] == "_partial_and_proof"
                for node in ast.walk(post)
            )
            payload_ok = False
            send_200 = False
            secret_keys: list[str] = []
            for node in ast.walk(post):
                if isinstance(node, ast.Dict):
                    keys = dict_keys(node)
                    secret_keys.extend(
                        key for key in keys
                        if key in {"secret_share", "network_secret_key", "token_material", "plaintext"}
                    )
                    if "partial_decryption" in keys:
                        index = keys.index("partial_decryption")
                        values = [value for key, value in zip(node.keys, node.values) if isinstance(key, ast.Constant) and isinstance(key.value, str)]
                        if index < len(values):
                            value = values[index]
                            payload_ok = (
                                isinstance(value, ast.Call)
                                and call_name(value.func) == "hex"
                                and len(value.args) == 1
                                and attribute_name(value.args[0]) == "response.value"
                            )
                if isinstance(node, ast.Call) and call_name(node.func) == "self._send":
                    if node.args and isinstance(node.args[0], ast.Constant) and node.args[0].value == 200:
                        send_200 = len(node.args) >= 2 and call_name(node.args[1]) == "payload"
            response_flow_ok = tuple_assignment and payload_ok and send_200
            no_secret_response = not secret_keys

    checks["CAPABILITY_PRODUCER_SITE_UNIQUE"] = (
        len(producer_sites) == 1
        and producer_sites[0]["context"] == "_partial_and_proof"
        and producer_sites[0]["args"] == [
            "state.operator_id",
            "state.share",
            "state.public_share",
            "ciphertext",
            "epoch",
        ]
    )
    checks["SECRET_SHARE_READ_CONFINED"] = (
        len(state_share_loads) == 1
        and state_share_loads[0]["context"] == "_partial_and_proof"
        and state_share_loads[0]["inside_create_partial"]
    )
    checks["SUCCESS_RESPONSE_DATAFLOW"] = response_flow_ok
    checks["NO_SECRET_IN_RESPONSE"] = no_secret_response
    expected_sensitive = {
        ("OperatorState.__init__", "self.share"),
        ("OperatorState.__init__", "self.public_share"),
        ("OperatorState.__init__", "self.identity"),
    }
    actual_sensitive = {(item["context"], item["target"]) for item in sensitive_writes}
    checks["LIFECYCLE_STATE_IMMUTABLE"] = actual_sensitive == expected_sensitive
    diagnostics["producer_sites"] = producer_sites
    diagnostics["state_share_loads"] = state_share_loads
    diagnostics["sensitive_state_writes"] = sensitive_writes

    crypto_tree = trees.get("crypto.py")
    ciphertext_fields: tuple[str, ...] = ()
    ciphertext_dict_keys: tuple[str, ...] = ()
    csprng_ok = False
    commitment_verifier_ok = False
    if crypto_tree is not None:
        ciphertext_classes = [
            node for node in ast.walk(crypto_tree)
            if isinstance(node, ast.ClassDef) and node.name == "Ciphertext"
        ]
        if len(ciphertext_classes) == 1:
            cls = ciphertext_classes[0]
            ciphertext_fields = tuple(
                node.target.id
                for node in cls.body
                if isinstance(node, ast.AnnAssign) and isinstance(node.target, ast.Name)
            )
            methods = class_methods(cls)
            to_dict = methods.get("to_dict")
            if to_dict is not None:
                returns = [
                    node.value for node in ast.walk(to_dict)
                    if isinstance(node, ast.Return) and isinstance(node.value, ast.Dict)
                ]
                if len(returns) == 1:
                    ciphertext_dict_keys = tuple(dict_keys(returns[0]))

        scalar_rng_classes = [
            node for node in ast.walk(crypto_tree)
            if isinstance(node, ast.ClassDef) and node.name == "ScalarRng"
        ]
        if len(scalar_rng_classes) == 1:
            methods = class_methods(scalar_rng_classes[0])
            scalar_calls = {
                call_name(node.func)
                for method_name in ("scalar", "bytes")
                for node in ast.walk(methods[method_name])
                if isinstance(node, ast.Call)
            }
            csprng_ok = {"secrets.randbelow", "secrets.token_bytes"} <= scalar_calls

        verify_functions = [
            node for node in ast.walk(crypto_tree)
            if isinstance(node, ast.FunctionDef) and node.name == "verify_threshold_result"
        ]
        if len(verify_functions) == 1:
            rendered = ast.unparse(verify_functions[0])
            commitment_verifier_ok = (
                "_plaintext_commitment" in rendered
                and "ciphertext.plaintext_commitment" in rendered
                and "expected_plaintext" not in rendered
            )

    source_text = "\n".join(
        (root / SOURCE_ROOT / filename).read_text(encoding="utf-8")
        for filename in sorted(trees)
    )
    checks["PUBLIC_CIPHERTEXT_NO_PLAINTEXT"] = (
        ciphertext_fields == EXPECTED_CIPHERTEXT_FIELDS
        and ciphertext_dict_keys == EXPECTED_CIPHERTEXT_FIELDS
        and "expected_plaintext" not in source_text
        and commitment_verifier_ok
    )
    diagnostics["ciphertext_fields"] = list(ciphertext_fields)
    diagnostics["ciphertext_dict_keys"] = list(ciphertext_dict_keys)

    experiment_tree = trees.get("experiment.py")
    experiment_csprng_ok = False
    threshold_gate_ok = False
    delivery_root_ok = False
    combine_sites = [
        item for item in all_calls if item["call"].rsplit(".", 1)[-1] == "combine_partials"
    ]
    if experiment_tree is not None:
        experiment_parents = parent_map(experiment_tree)
        make_functions = [
            node for node in ast.walk(experiment_tree)
            if isinstance(node, ast.FunctionDef) and node.name == "make_ciphertext"
        ]
        if len(make_functions) == 1:
            encrypt_calls = [
                node for node in ast.walk(make_functions[0])
                if isinstance(node, ast.Call) and call_name(node.func).rsplit(".", 1)[-1] == "encrypt_capability"
            ]
            experiment_csprng_ok = (
                len(encrypt_calls) == 1
                and len(encrypt_calls[0].args) == 4
                and all(keyword.arg != "seed" for keyword in encrypt_calls[0].keywords)
            )

        run_functions = [
            node for node in ast.walk(experiment_tree)
            if isinstance(node, ast.FunctionDef) and node.name == "run_order"
        ]
        if len(run_functions) == 1:
            run_order = run_functions[0]
            initial_none = any(
                assigned_name(node, "plaintext")
                and isinstance(assignment_value(node), ast.Constant)
                and assignment_value(node).value is None
                for node in run_order.body
            )
            combine_calls = [
                node for node in ast.walk(run_order)
                if isinstance(node, ast.Call) and call_name(node.func).rsplit(".", 1)[-1] == "combine_partials"
            ]
            combine_guarded = False
            if len(combine_calls) == 1:
                parent_if = nearest(combine_calls[0], experiment_parents, (ast.If,))
                combine_guarded = isinstance(parent_if, ast.If) and call_name(parent_if.test) == "threshold_reached"
            threshold_gate_ok = initial_none and len(combine_calls) == 1 and combine_guarded and len(combine_sites) == 1

            gateway_assignments = [
                assignment_value(node)
                for node in run_order.body
                if assigned_name(node, "gateway_accepted")
            ]
            success_if = any(
                isinstance(node, ast.If)
                and call_name(node.test) == "gateway_accepted"
                and any(
                    isinstance(child, ast.Call) and call_name(child.func) == "ledger.mark_success"
                    for child in ast.walk(node)
                )
                for node in run_order.body
            )
            delivery_root_ok = (
                len(gateway_assignments) == 1
                and gateway_assignments[0] is not None
                and compare_actual_consumer(gateway_assignments[0])
                and success_if
            )

    checks["EXPERIMENT_USES_CSPRNG"] = csprng_ok and experiment_csprng_ok
    checks["THRESHOLD_GATES_PLAINTEXT"] = threshold_gate_ok
    checks["DELIVERY_ROOT_GUARDED"] = delivery_root_ok
    diagnostics["combine_sites"] = combine_sites

    operator_source = (root / SOURCE_ROOT / "operator_server.py").read_text(encoding="utf-8")
    network_source = (root / SOURCE_ROOT / "network_identity.py").read_text(encoding="utf-8")
    coordinator_source = (root / SOURCE_ROOT / "coordinator.py").read_text(encoding="utf-8")
    runner_source = (root / "scripts" / "run_two_host.py").read_text(encoding="utf-8")
    checks["RUNTIME_SOURCE_DIGEST_BOUND"] = (
        operator_source.count('"runtime_source_digest": RUNTIME_SOURCE_DIGEST') == 2
        and "runtime_source_digest=RUNTIME_SOURCE_DIGEST" in operator_source
        and '"runtime_source_digest": runtime_source_digest' in network_source
        and "payload.get(\"runtime_source_digest\") != self.expected_runtime_source_digest" in coordinator_source
        and "runtime_source_digest=self.expected_runtime_source_digest" in coordinator_source
        and "health[i].get(\"runtime_source_digest\") == RUNTIME_SOURCE_DIGEST" in runner_source
        and '"runtime_source_digest_matches": runtime_source_ok' in runner_source
    )

    obligations = {
        "LC1_SOURCE_PRODUCER_COMPLETENESS": {
            "status": "PASS" if all(
                checks[name]
                for name in (
                    "HANDLER_CLASS_EXACT",
                    "REQUEST_ENTRY_METHODS_EXACT",
                    "ROUTE_GUARDS_EXACT",
                    "RESPONSE_PRIMITIVE_UNIQUE",
                    "CAPABILITY_PRODUCER_SITE_UNIQUE",
                    "SUCCESS_RESPONSE_DATAFLOW",
                    "THRESHOLD_GATES_PLAINTEXT",
                    "DELIVERY_ROOT_GUARDED",
                    "RUNTIME_SOURCE_DIGEST_BOUND",
                )
            ) else "FAIL",
            "scope": "application-level request, response, aggregation, and delivery sites in the frozen Python source",
        },
        "LC3_SOURCE_SECRET_CONFINEMENT": {
            "status": "PASS" if all(
                checks[name]
                for name in (
                    "SECRET_SHARE_READ_CONFINED",
                    "NO_SECRET_IN_RESPONSE",
                    "PUBLIC_CIPHERTEXT_NO_PLAINTEXT",
                    "EXPERIMENT_USES_CSPRNG",
                )
            ) else "FAIL",
            "scope": "source-level dataflow from operator share and high-entropy capability material",
        },
        "LC5_SOURCE_LIFECYCLE_CLOSURE": {
            "status": "PASS" if all(
                checks[name]
                for name in (
                    "SOURCE_MODULE_SET_EXACT",
                    "OPERATOR_IMPORT_CLOSURE_EXACT",
                    "NO_DYNAMIC_LOADING",
                    "NO_PROCESS_SPAWN",
                    "SINGLE_LISTENER",
                    "LIFECYCLE_STATE_IMMUTABLE",
                    "RUNTIME_SOURCE_DIGEST_BOUND",
                )
            ) else "FAIL",
            "scope": "frozen source tree and standard interpreter loading semantics",
        },
        "LC7_SOURCE_DELIVERY_ROOT": {
            "status": "PASS" if checks["THRESHOLD_GATES_PLAINTEXT"] and checks["DELIVERY_ROOT_GUARDED"] else "FAIL",
            "scope": "the run_order usable-delivery root in the controlled service",
        },
    }

    passed = all(checks.values()) and all(item["status"] == "PASS" for item in obligations.values())
    hashes = {
        f"{SOURCE_ROOT.as_posix()}/{filename}": sha256_file(root / SOURCE_ROOT / filename)
        for filename in sorted(trees)
    }
    return {
        "schema": SCHEMA,
        "status": "PASS" if passed else "FAIL",
        "checks": checks,
        "obligations": obligations,
        "source_sha256": hashes,
        "diagnostics": diagnostics,
        "claim": (
            "Under standard Python source semantics for the frozen module set, every application-level "
            "respond success is produced by the single declared partial-decryption site, operator shares "
            "flow to that site only, usable plaintext is created only after threshold aggregation, and "
            "the frozen source contains no dynamic loader, process spawn, second listener, or key replacement path."
        ),
        "assumptions": [
            "the executed bytes equal the separately verified source hashes",
            "the Python interpreter and imported standard-library modules implement their documented semantics",
            "the operating system, native runtime, and hardware are not compromised",
        ],
        "not_claimed": [
            "absence of operating-system, interpreter, firmware, side-channel, or physical attacks",
            "hardware non-exportability",
            "coverage of off-language acquisition routes",
            "deployment-wide refinement",
            "independent economic operators",
        ],
    }


def print_result(result: dict[str, Any]) -> None:
    checks = result["checks"]
    width = max(len(name) for name in checks)
    for name, ok in checks.items():
        print(f"{name.ljust(width)}  {'PASS' if ok else 'FAIL'}")
    for name, item in result["obligations"].items():
        print(f"{name}={item['status']}")
    print(f"SOURCE_COVERAGE_KERNEL={result['status']}")


def main() -> int:
    parser = argparse.ArgumentParser(description="Independently check source-level coverage obligations.")
    parser.add_argument("--root", type=Path, default=ROOT)
    parser.add_argument("--output", type=Path, default=ROOT / "results" / "source_coverage_kernel.v1.json")
    args = parser.parse_args()
    result = analyze(args.root)
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(result, indent=2, sort_keys=True) + "\n", encoding="utf-8", newline="\n")
    print_result(result)
    print(f"SOURCE_COVERAGE_RESULT={args.output}")
    return 0 if result["status"] == "PASS" else 1


if __name__ == "__main__":
    raise SystemExit(main())