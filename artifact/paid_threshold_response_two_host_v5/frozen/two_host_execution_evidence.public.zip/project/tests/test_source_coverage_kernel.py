from __future__ import annotations

from pathlib import Path
import sys
import unittest

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "scripts"))

from source_coverage_kernel import analyze  # noqa: E402


class SourceCoverageKernelTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls) -> None:
        cls.result = analyze(ROOT)

    def test_baseline_passes_every_check(self) -> None:
        self.assertEqual(self.result["status"], "PASS")
        self.assertTrue(all(self.result["checks"].values()))

    def test_consequential_obligations_are_source_discharged(self) -> None:
        self.assertEqual(
            {
                name: item["status"]
                for name, item in self.result["obligations"].items()
            },
            {
                "LC1_SOURCE_PRODUCER_COMPLETENESS": "PASS",
                "LC3_SOURCE_SECRET_CONFINEMENT": "PASS",
                "LC5_SOURCE_LIFECYCLE_CLOSURE": "PASS",
                "LC7_SOURCE_DELIVERY_ROOT": "PASS",
            },
        )

    def test_claim_keeps_environment_and_off_language_limits_explicit(self) -> None:
        exclusions = " ".join(self.result["not_claimed"])
        self.assertIn("operating-system", exclusions)
        self.assertIn("hardware non-exportability", exclusions)
        self.assertIn("off-language", exclusions)
        self.assertIn("deployment-wide", exclusions)


if __name__ == "__main__":
    unittest.main()